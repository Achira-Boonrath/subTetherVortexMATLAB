function [c,ceq] = nonlcon(x,x_in,rbf_coeff,rho)
c = 0;
ceq = 0;


end

