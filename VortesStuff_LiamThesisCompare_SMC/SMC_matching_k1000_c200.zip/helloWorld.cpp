#include "MyLibraryNet/helloWorld.h"

#include <iostream>
#include <stdio.h>

void helloWorld()
 {
	 std::cout << "\n Hello world! \n \n";
 }