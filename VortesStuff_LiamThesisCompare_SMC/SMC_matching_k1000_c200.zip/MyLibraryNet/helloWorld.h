#ifndef HELLOWORLD_H    // To make sure you don't declare the function more than once by including the header multiple times.
#define HELLOWORLD_H

// Include all libraries needed by cpp files in this header
#include <iostream>
#include <stdio.h>

// define headers of cpp functions
void helloWorld();

#endif