#ifndef MATRIXMULT_H  
#define MATRIXMULT_H


#include<iostream>
#include<math.h>
#include<vector>




//std::vector<float> matrixMult(float a[], std::vector<float> b);

std::vector<double> matrixMult(double a[3][6], std::vector<double>& b);

#endif MATRIXMULT_H






